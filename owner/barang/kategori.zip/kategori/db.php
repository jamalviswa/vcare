<?php
$username = 'xxdatabasexx';
$password = 'xxdbpasswordxx';
$connection = new PDO( 'mysql:host=localhost;dbname=xxdatabasexx', $username, $password );

?>